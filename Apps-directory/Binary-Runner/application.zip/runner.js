(function () {
  "use strict";

  var BASE = new URL("./", document.baseURI).href;
  var TARGET = "local/service/updater";
  var RUNNER = TARGET + "/jscalated-runner";
  var MAX_BYTES = 16 * 1024 * 1024;
  var state = { apps: null, appsRoot: null, target: null, runner: null, entries: [], installedVersion: null };

  var choice = document.getElementById("choice");
  var detail = document.getElementById("detail");
  var status = document.getElementById("status");
  var log = document.getElementById("log");
  var stageButton = document.getElementById("stage");
  var inspectButton = document.getElementById("inspect");
  var restoreButton = document.getElementById("restore");

  function say(message) {
    status.textContent = message;
    log.textContent += message + "\n";
  }
  function fail(error) {
    say("Stopped: " + (error && error.message || String(error)));
  }
  function isDirectory(value) {
    return !!value && typeof value.getFilesAndDirectories === "function";
  }
  async function child(directory, name) {
    var entries = await directory.getFilesAndDirectories();
    return entries.find(function (entry) { return entry.name === name; }) || null;
  }
  async function entryAt(root, path) {
    try {
      return await root.get(path);
    } catch (firstError) {
      var current = root;
      var parts = path.split("/");
      for (var i = 0; i < parts.length; i++) {
        if (!isDirectory(current)) throw firstError;
        var entries = await current.getFilesAndDirectories();
        current = entries.find(function (entry) { return entry.name === parts[i]; });
        if (!current) throw firstError;
      }
      return current;
    }
  }
  async function directoryAt(root, path) {
    var entry = await entryAt(root, path);
    if (!isDirectory(entry)) throw Error("Missing /data/" + path);
    return entry;
  }
  function readBytes(file) {
    return new Promise(function (resolve, reject) {
      if (!file || isDirectory(file) || file.size > MAX_BYTES) {
        reject(Error("File is missing, a directory, or too large"));
        return;
      }
      var reader = new FileReader();
      reader.onload = function () { resolve(new Uint8Array(reader.result)); };
      reader.onerror = function () { reject(reader.error || Error("FileReader failed")); };
      reader.readAsArrayBuffer(file);
    });
  }
  function same(left, right) {
    if (left.length !== right.length) return false;
    for (var i = 0; i < left.length; i++) if (left[i] !== right[i]) return false;
    return true;
  }
  function requestBytes(url) {
    return new Promise(function (resolve, reject) {
      var request = new XMLHttpRequest();
      request.open("GET", url, true);
      request.responseType = "arraybuffer";
      request.timeout = 30000;
      request.onload = function () {
        if (request.status !== 200 || !request.response) reject(Error("GET " + request.status + " for " + url));
        else resolve(new Uint8Array(request.response));
      };
      request.onerror = function () { reject(Error("Network error fetching " + url)); };
      request.ontimeout = function () { reject(Error("Timed out fetching " + url)); };
      request.send();
    });
  }
  async function sha256(bytes) {
    if (!crypto.subtle || !crypto.subtle.digest) throw Error("SHA-256 is unavailable on this page");
    var digest = new Uint8Array(await crypto.subtle.digest("SHA-256", bytes));
    return Array.from(digest).map(function (value) { return value.toString(16).padStart(2, "0"); }).join("");
  }
  function validEntry(entry) {
    return entry && typeof entry.name === "string" && /^[A-Za-z0-9._-]+$/.test(entry.name) &&
      (entry.kind === "binary" || entry.kind === "script") &&
      entry.path === "payloads/" + (entry.kind === "binary" ? "binaries" : "scripts") + "/" + entry.name &&
      Number.isInteger(entry.size) && entry.size > 0 && entry.size <= MAX_BYTES &&
      typeof entry.sha256 === "string" && /^[a-f0-9]{64}$/.test(entry.sha256);
  }
  async function loadCatalog() {
    if (!BASE || new URL(BASE).origin !== location.origin) throw Error("App assets must load from the installed app");
    var bytes = await requestBytes(new URL("payloads/catalog.json", BASE).href);
    var parsed = JSON.parse(new TextDecoder("utf-8").decode(bytes));
    if (!Array.isArray(parsed) || !parsed.every(validEntry)) throw Error("Invalid payload catalog");
    state.entries = parsed;
    choice.replaceChildren();
    parsed.forEach(function (entry, index) {
      var option = document.createElement("option");
      option.value = String(index);
      option.textContent = entry.name + " (" + entry.kind + ")";
      choice.appendChild(option);
    });
    stageButton.disabled = !parsed.length;
    updateDetail();
    say(parsed.length ? parsed.length + " bundled file(s) available." : "No files are bundled yet.");
  }
  function updateDetail() {
    var entry = state.entries[Number(choice.value)];
    detail.textContent = entry ? entry.kind + ", " + entry.size + " bytes, SHA-256 " + entry.sha256 : "";
  }
  async function storage() {
    if (!state.apps) {
      if (navigator.b2g && typeof navigator.b2g.getDeviceStorage === "function") {
        state.apps = navigator.b2g.getDeviceStorage("apps");
      } else if (typeof navigator.getDeviceStorage === "function") {
        state.apps = navigator.getDeviceStorage("apps");
      } else {
        throw Error("The installed core app does not expose the apps DeviceStorage API");
      }
      if (!state.apps || typeof state.apps.getRoot !== "function") {
        throw Error("The apps DeviceStorage filesystem interface is unavailable");
      }
      state.appsRoot = await state.apps.getRoot();
    }
    return state.apps;
  }
  async function preflight() {
    await storage();
    state.target = await directoryAt(state.appsRoot, TARGET);
    var init = await child(state.target, "init");
    if (!init || isDirectory(init)) throw Error("Updater init marker missing; boot would restore stock");
    var installed = await directoryAt(state.target, "installed");
    var manifests = (await installed.getFilesAndDirectories()).filter(function (file) {
      return /^updater-.*\.toml$/.test(file.name) && !isDirectory(file);
    });
    if (manifests.length !== 1) throw Error("Expected one installed updater manifest; found " + manifests.length);
    var manifest = new TextDecoder("utf-8").decode(await readBytes(manifests[0]));
    var match = manifest.match(/\bversion\s*=\s*"([0-9]+(?:\.[0-9]+)*)"/);
    if (!match) throw Error("Installed updater version is unavailable");
    state.installedVersion = match[1];
    var current = await child(state.target, "updater-daemon");
    if (!current || isDirectory(current)) throw Error("Updater executable is missing");
    var bytes = await readBytes(current);
    var runner = await child(state.target, "jscalated-runner");
    if (runner && !isDirectory(runner)) throw Error("Runner backup path is a file");
    state.runner = runner;
    return bytes;
  }
  async function runnerDir() {
    if (!state.runner) state.runner = await state.target.createDirectory("jscalated-runner");
    return state.runner;
  }
  async function copy(directory, name, destination) {
    var result = await directory.copyTo(name, destination, { targetStorage: state.apps, keepBoth: false });
    if (result !== true) throw Error("copyTo failed: " + String(result));
  }
  async function move(directory, name, destination) {
    var result = await directory.moveTo(name, destination, { targetStorage: state.apps, keepBoth: false });
    if (result !== true) throw Error("moveTo failed: " + String(result));
  }
  async function assertFile(directory, name, expected) {
    var file = await child(directory, name);
    if (!same(await readBytes(file), expected)) throw Error("Readback mismatch for " + name);
  }
  async function firstUseBackup(current) {
    var runner = await runnerDir();
    var original = await child(runner, "first-use-backup");
    if (!original) {
      original = await runner.createDirectory("first-use-backup");
      await copy(state.target, "updater-daemon", RUNNER + "/first-use-backup");
      await assertFile(original, "updater-daemon", current);
      say("Saved first-use updater backup.");
    } else {
      var backup = isDirectory(original) && await child(original, "updater-daemon");
      if (!backup || isDirectory(backup) || !backup.size) {
        throw Error("Incomplete first-use backup; no replacement attempted");
      }
    }
    return original;
  }
  async function replaceWith(bytes) {
    var current = await preflight();
    await firstUseBackup(current);
    var id = Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);
    var stageName = "stage-" + id;
    var backupName = "backup-" + id;
    var stage = await state.runner.createDirectory(stageName);
    await stage.createFile("updater-daemon", {
      ifExists: "fail",
      data: new Blob([bytes], { type: "application/octet-stream" })
    });
    await assertFile(stage, "updater-daemon", bytes);
    var backup = await state.runner.createDirectory(backupName);
    var moved = false;
    try {
      await move(state.target, "updater-daemon", RUNNER + "/" + backupName);
      moved = true;
      await assertFile(backup, "updater-daemon", current);
      await copy(backup, "updater-daemon", TARGET);
      await assertFile(state.target, "updater-daemon", current);
      await copy(stage, "updater-daemon", TARGET);
      await assertFile(state.target, "updater-daemon", bytes);
      say("Selected bytes staged. Previous daemon saved in " + backupName + ".");
    } catch (error) {
      if (moved || await child(backup, "updater-daemon")) {
        try {
          await copy(backup, "updater-daemon", TARGET);
          await assertFile(state.target, "updater-daemon", current);
          say("Previous updater bytes restored after error.");
        } catch (restoreError) {
          say("RESTORE FAILED: " + restoreError.message + ". Backup remains at /data/" + RUNNER + "/" + backupName);
        }
      }
      throw error;
    }
  }
  async function selectedBytes(entry) {
    var bytes = await requestBytes(new URL(entry.path, BASE).href);
    if (bytes.length !== entry.size || await sha256(bytes) !== entry.sha256) throw Error("Bundled file failed size or SHA-256 verification");
    if (entry.kind === "binary" &&
        (bytes[0] !== 0x7f || bytes[1] !== 0x45 || bytes[2] !== 0x4c || bytes[3] !== 0x46 || bytes[4] !== 1 || bytes[5] !== 1 || bytes[18] !== 40 || bytes[19] !== 0)) {
      throw Error("Selected binary is not a 32-bit ARM ELF");
    }
    if (entry.kind === "script" && new TextDecoder("utf-8").decode(bytes.slice(0, 17)) !== "#!/system/bin/sh\n") {
      throw Error("Selected script needs a /system/bin/sh shebang");
    }
    return bytes;
  }
  async function run(work) {
    stageButton.disabled = inspectButton.disabled = restoreButton.disabled = true;
    try { await work(); }
    catch (error) { fail(error); }
    finally {
      inspectButton.disabled = restoreButton.disabled = false;
      stageButton.disabled = !state.entries.length;
    }
  }
  choice.onchange = updateDetail;
  inspectButton.onclick = function () { return run(async function () {
    var current = await preflight();
    say("Updater present: " + current.length + " bytes. First-use backup " +
      (state.runner && await child(state.runner, "first-use-backup") ? "exists." : "not created yet."));
    say("Installed updater version: " + state.installedVersion + ". The apps storage API cannot read /system/kaios/updater.ver, so the stock version cannot be checked here.");
  }); };
  stageButton.onclick = function () { return run(async function () {
    var entry = state.entries[Number(choice.value)];
    if (!entry) throw Error("Choose a bundled file");
    var bytes = await selectedBytes(entry);
    await preflight();
    if (!confirm("Stage " + entry.name + " as updater-daemon? Installed updater version: " + state.installedVersion + ". The stock version could not be checked; boot may restore stock. This changes a system service and requires a full phone reboot. The first-use daemon will be backed up.")) return;
    await replaceWith(bytes);
    say("Fully power off and reboot the phone to try the selected file. Check service state and SELinux logs after boot.");
    alert("Staging complete. Fully reboot the phone before checking the result.");
  }); };
  restoreButton.onclick = function () { return run(async function () {
    await preflight();
    var original = state.runner && await child(state.runner, "first-use-backup");
    if (!isDirectory(original)) throw Error("No first-use backup exists");
    var bytes = await readBytes(await child(original, "updater-daemon"));
    if (!confirm("Restore the updater file saved on first use? A full phone reboot is required.")) return;
    await replaceWith(bytes);
    say("First-use updater bytes restored. Fully reboot the phone.");
    alert("Restore staged. Fully reboot the phone.");
  }); };
  loadCatalog().catch(fail);
})();
